#!/bin/bash
#SBATCH --job-name=bps
#SBATCH --output=logs/%x_%A_%a.out
#SBATCH --error=logs/%x_%A_%a.err
#SBATCH -n 32
#SBATCH --mem=64G
#SBATCH --time=23:30:00
#SBATCH --partition=compute
#
# One Slurm array task per experiment run.
#
# The pipeline calls joblib with n_jobs=-5, i.e. "every core on the machine
# minus four", counted from the node rather than from the allocation. The COMA
# docs note that CPU limits are not enforced, so this does not fail -- it just
# means the process count follows the node, and -n mainly signals to other
# users which cores are spoken for. 32 on a 64-thread node leaves room for a
# second job without either one stalling.
#
# No --gres line on purpose: Prosimos is a sequential discrete-event simulator
# and none of the numerical work touches CUDA. Requesting a GPU would leave it
# idle and lengthen the queue wait for everyone.
#
# Run numbers come from:
#
#     python run_bpic2013_experiments.py --list
#
# Submit whatever is still outstanding:
#
#     sbatch --array=0-32 run_array.sh
#     sbatch --array=12-17 run_array.sh          # just phase 2
#
# Tasks are queued and run as nodes free up. Each writes to its own output
# folder and reads nothing from the others, so order does not matter and one
# failure does not affect the rest.

set -euo pipefail

# NOTE: logs/ must already exist at submit time. Slurm opens the --output file
# before this script runs, and a missing directory makes the job fail silently
# with no log to explain why. The mkdir below only helps on later submissions.
cd "$SLURM_SUBMIT_DIR/../../backend"
mkdir -p "$SLURM_SUBMIT_DIR/logs"

# Keep BLAS single-threaded: joblib already parallelises across processes and
# nested threading would multiply the load.
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1

export PYTHONIOENCODING=utf-8

# The cluster ships Python 3.9 and has no python module, so the environment is
# a Miniforge conda env (the COMA docs rule out Miniconda over licensing).
source ~/miniforge3/etc/profile.d/conda.sh
conda activate bps

echo "host      : $(hostname)"
echo "array job : $SLURM_ARRAY_JOB_ID  task $SLURM_ARRAY_TASK_ID"
echo "cores (-n): ${SLURM_NTASKS:-unset}"
echo "started   : $(date)"
echo

python run_bpic2013_experiments.py --index "$SLURM_ARRAY_TASK_ID"

echo
echo "finished  : $(date)"

"""
Aggregates ALL THREE KPIs (cycle_time, waiting_time, processing_time) from
the already-downloaded 2013 SA result folders into one long CSV.

No new SA runs are needed: the tool already computed all three KPIs for
every (method, sample_size, seed) config, saved as sibling subfolders under
each run's sensitivity_analysis_outputs/:
    2013_{method}_cycle_n{size}_c{cases}_seed{seed}[_suffix]/   <- cycle_time
    2013_{method}_w_n{size}_c{cases}_seed{seed}[_suffix]/       <- waiting_time
    2013_{method}_p_n{size}_c{cases}_seed{seed}[_suffix]/       <- processing_time

Usage:
    python3 aggregate_2013_multikpi.py <sobol_base_dir> <morris_base_dir> <output_csv>

Example:
    python3 aggregate_2013_multikpi.py ~/Desktop/sa_results_only ~/Desktop/morris_results_only sa_indices_2013_multikpi.csv
"""
import json
import re
import sys
from pathlib import Path
import pandas as pd

NAME_TO_CODE = {
    "Arrival Calendar": "AC",
    "Arrival Distribution": "AD",
    "Resource Calendars": "RC",
    "Resource Numbers": "RN",
    "Tasks and Resources Distributions": "TR",
    "Gateways": "GW",
}

FOLDER_RE = re.compile(
    r"^2013_(sobol|morris)_cycle_n(\d+)_c(\d+)_seed(\d+)(?:_.*)?$"
)

RESULT_FILENAME = {"sobol": "sobol_first_and_total_order.json",
                    "morris": "morris_first_order.json"}
VALUE_KEY = {"sobol": "ST", "morris": "mu_star"}

# maps our kpi label -> the letter used in the tool's subfolder naming,
# and the expected value in user_config.json's "kpi" field (for verification)
KPI_VARIANTS = {
    "cycle_time":       (None, "cycle_time"),   # None = subfolder name == run_dir.name (no substitution)
    "waiting_time":     ("w",  "waiting_time"),
    "processing_time":  ("p",  "processing_time"),
}

# walks through one base folder (sobol or morris) and pulls out every KPI's
# results for every run folder it finds inside it
def process_base_dir(base_dir: Path, rows: list, skipped: list):
    for run_dir in sorted(base_dir.iterdir()):
        if not run_dir.is_dir():
            continue
        # only folders matching the expected naming pattern are run folders,
        # anything else (stray files, unrelated folders) is skipped
        m = FOLDER_RE.match(run_dir.name)
        if not m:
            continue
        method, n_samples, cases, seed = m.group(1), int(m.group(2)), int(m.group(3)), int(m.group(4))

        # each run folder actually has 3 KPI variants inside it (cycle/waiting/processing),
        # so we loop over all 3 and build the right subfolder name for each
        for kpi_label, (letter, expected_kpi) in KPI_VARIANTS.items():
            if letter is None:
                subfolder_name = run_dir.name
            else:
                subfolder_name = run_dir.name.replace("_cycle_", f"_{letter}_")

            result_subdir = run_dir / "sensitivity_analysis_outputs" / subfolder_name
            result_file = result_subdir / RESULT_FILENAME[method]

            if not result_file.exists():
                skipped.append(f"{run_dir.name} [{kpi_label}] (no file at {result_subdir.name})")
                continue

            # Safety check against user_config.json
            config_path = result_subdir / "user_config.json"
            if config_path.exists():
                with open(config_path) as f:
                    cfg = json.load(f)
                if cfg.get("kpi") != expected_kpi:
                    skipped.append(f"{run_dir.name} [{kpi_label}] (subfolder KPI is "
                                    f"'{cfg.get('kpi')}', expected '{expected_kpi}')")
                    continue

            with open(result_file) as f:
                data = json.load(f)

            # pull out the SA value (ST or mu_star) for every parameter group
            # in this result file, and turn it into one row of our output table
            value_key = VALUE_KEY[method]
            for entry in data:
                group_name = entry["group"] if "group" in entry else entry.get("name")
                if group_name not in NAME_TO_CODE:
                    raise ValueError(f"Unrecognised group '{group_name}' in {result_file}")
                rows.append(dict(
                    dataset="2013",
                    kpi=kpi_label,
                    method=method,
                    seed=seed,
                    sample_size=n_samples,
                    parameter=NAME_TO_CODE[group_name],
                    value=entry[value_key],
                ))


def main():
    # first 2 command-line args are the sobol/morris folders, 3rd (optional) is the output filename
    sobol_dir = Path(sys.argv[1])
    morris_dir = Path(sys.argv[2])
    output_csv = sys.argv[3] if len(sys.argv) > 3 else "sa_indices_2013_multikpi.csv"

    rows, skipped = [], []
    process_base_dir(sobol_dir, rows, skipped)
    process_base_dir(morris_dir, rows, skipped)

    df = pd.DataFrame(rows)
    df.to_csv(output_csv, index=False)

    print(f"Saved {len(df)} rows to {output_csv}\n")
    print(df.groupby(["kpi", "method", "sample_size"])["seed"].nunique().to_string())

    # print anything that couldn't be read, so it's easy to spot missing/broken runs
    if skipped:
        print(f"\n--- Skipped {len(skipped)} (config, kpi) combinations ---")
        for s in skipped:
            print(f"  {s}")


if __name__ == "__main__":
    main()

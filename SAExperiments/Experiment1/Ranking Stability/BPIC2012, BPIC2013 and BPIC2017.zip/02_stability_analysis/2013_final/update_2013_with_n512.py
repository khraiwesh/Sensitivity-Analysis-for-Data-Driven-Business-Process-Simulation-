"""
update_2013_with_n512.py
--------------------------
Regenerates all 2013 SA aggregation CSVs now that n=512 has all 3 seeds
for BOTH Sobol and Morris (previously Sobol's n=512 only had seed100,
so it was excluded from the stability analysis; the reference ranking
was taken at n=256 instead). Run this after moving/renaming any new
folders into sa_results_only/ and morris_results_only/.

Steps:
  1. Re-run the multi-KPI aggregator over the updated folders
  2. Filter to only (kpi, method, sample_size) combos with all 3 seeds
  3. Split into per-KPI CSVs (cycle_time / waiting_time / processing_time)
  4. Report which sample sizes are now complete, so you know whether the
     Sobol reference ranking should move from n=256 to n=512

Run from ~/Desktop/stability_2012_2017:
    python3 update_2013_with_n512.py
"""
import subprocess
import sys
import pandas as pd

SOBOL_DIR = "/Users/suedaozkaya/Desktop/sa_results_only"
MORRIS_DIR = "/Users/suedaozkaya/Desktop/morris_results_only"

print("=" * 70)
print("STEP 1: Re-running multi-KPI aggregator")
print("=" * 70)
result = subprocess.run(
    [sys.executable, "aggregate_2013_multikpi.py", SOBOL_DIR, MORRIS_DIR,
     "sa_indices_2013_multikpi.csv"],
    capture_output=True, text=True
)
print(result.stdout)
if result.returncode != 0:
    print("ERROR during aggregation:")
    print(result.stderr)
    sys.exit(1)

print("\n" + "=" * 70)
print("STEP 2: Filtering to complete (3-seed) combos")
print("=" * 70)
df = pd.read_csv("sa_indices_2013_multikpi.csv")
# count how many distinct seeds we actually have for each (kpi, method, sample_size)
seed_counts = df.groupby(["kpi", "method", "sample_size"])["seed"].nunique()
# we only trust a combo if all 3 seeds are present, otherwise it's incomplete
complete = seed_counts[seed_counts == 3].index
dropped = seed_counts[seed_counts != 3]

if len(dropped) > 0:
    print("Dropping incomplete (kpi, method, sample_size) combos:")
    print(dropped.to_string())
else:
    print("Nothing dropped -- all combos have 3 seeds.")

# keep only the rows whose (kpi, method, sample_size) combo is in the complete list
mask = df.set_index(["kpi", "method", "sample_size"]).index.isin(complete)
filtered = df[mask]
filtered.to_csv("sa_indices_2013_multikpi_clean.csv", index=False)
print(f"\nSaved sa_indices_2013_multikpi_clean.csv -- {len(filtered)} rows")
print(filtered.groupby(["kpi", "method", "sample_size"])["seed"].nunique().to_string())

print("\n" + "=" * 70)
print("STEP 3: Splitting into per-KPI CSVs")
print("=" * 70)
for kpi in filtered["kpi"].unique():
    sub = filtered[filtered["kpi"] == kpi].copy()
    sub["dataset"] = f"2013_{kpi}"
    sub = sub[["dataset", "method", "seed", "sample_size", "parameter", "value"]]
    fname = f"sa_indices_2013_{kpi}.csv"
    sub.to_csv(fname, index=False)
    print(f"Wrote {fname} ({len(sub)} rows)")

# also write the plain "sa_indices_2013.csv" (cycle_time only, in the
# original 6-column format used by spearman_stability_v2.py for the main
# analysis)
cycle = filtered[filtered["kpi"] == "cycle_time"].copy()
cycle["dataset"] = "2013"
cycle = cycle[["dataset", "method", "seed", "sample_size", "parameter", "value"]]
cycle.to_csv("sa_indices_2013.csv", index=False)
print(f"Wrote sa_indices_2013.csv ({len(cycle)} rows) -- main cycle-time analysis file")

print("\n" + "=" * 70)
print("STEP 4: Sample-size completeness per method (for reference-ranking check)")
print("=" * 70)
for method in ["sobol", "morris"]:
    sizes = sorted(cycle[cycle.method == method]["sample_size"].unique())
    max_size = max(sizes) if sizes else None
    print(f"  {method}: complete sample sizes = {sizes}  ->  largest = {max_size}")

print("\nIf Sobol's largest complete size is now 512 (matching Morris), the")
print("reference ranking basis for Sobol should move from n=256 to n=512 --")
print("check the printed sizes above and update Table~\\ref{tab:reference_rankings}")
print("in methodology_review.tex accordingly if so.")

#!/usr/bin/env python3
"""
Spearman stability analysis for SA rankings.

WHAT THIS SCRIPT DOES
----------------------
Given raw SA outputs (Sobol S_T and Morris mu* values, per dataset / method /
seed / sample size / parameter group), this script computes:

  1. Seed stability:    pairwise Spearman rho across seeds, per sample size.
                         -> "if I'd used a different random seed, would I have
                            gotten the same ranking?"
  2. Convergence:       Spearman rho between consecutive sample sizes, per seed.
                         -> "does the ranking stop changing as I add more samples?"
  3. Method agreement:  Morris-vs-Sobol rho at the largest sample size.
                         -> "do the two SA methods agree on the ranking?"
  4. Reference rankings: seed-averaged indices at the largest sample size.
                         -> this is the single source of truth used later in
                            the perturbation-validation evaluation.

WHY A "v2"
----------
The original version of this script assumed a FIXED set of 5 parameter
groups (RC, AD, RN, TR, AC) for every dataset. That assumption breaks for
this data: BPIC 2017's Sobol run includes a 6th group, Gateways (GW), while
every other dataset/method combination has only the 5 core groups. This
version therefore:
  - infers the parameter set PER (dataset, method) group directly from the
    data, instead of assuming a fixed list;
  - computes seed-stability and convergence using whatever parameter set is
    actually present for that dataset/method (5 or 6 items);
  - for the Sobol-vs-Morris method-agreement comparison, restricts the
    comparison to the INTERSECTION of parameters present in both methods for
    that dataset (so BPIC 2017's Gateways group, which Morris doesn't have
    here, is simply left out of that one specific comparison -- it is still
    included everywhere else, e.g. in the seed-stability/convergence results
    and in the reference ranking table).

INPUT FORMAT
------------
One CSV with columns: dataset, method, seed, sample_size, parameter, value
  - method in {sobol, morris}
  - value = S_T for sobol, mu* for morris
  - parameter is whatever group codes are present for that dataset/method
    (e.g. RC, AD, RN, TR, AC, and for 2017 Sobol also GW)

NOTE ON P-VALUES
-----------------
With only 5 (or 6) items being ranked, scipy's asymptotic p-value
approximation for Spearman's rho is unreliable. An EXACT two-sided
permutation p-value is computed instead, using all k! permutations of a
ranking of size k (120 permutations for k=5, 720 for k=6).
"""

import itertools
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr


def exact_perm_pvalue(rho: float, k: int) -> float:
    """Exact two-sided permutation p-value for Spearman's rho with k items."""
    base = np.arange(k)
    rhos = []
    for perm in itertools.permutations(range(k)):
        r, _ = spearmanr(base, np.array(perm))
        rhos.append(r)
    rhos = np.array(rhos)
    return float(np.mean(np.abs(rhos) >= abs(rho) - 1e-12))


def ranking_from_values(sub: pd.DataFrame, params: list) -> pd.Series:
    """Rank the given parameter list by value (1 = largest index = most influential)."""
    s = sub.set_index("parameter")["value"].reindex(params)
    if s.isna().any():
        missing = s[s.isna()].index.tolist()
        raise ValueError(f"Missing values for parameters {missing} in this slice.")
    return s.rank(ascending=False, method="average")


# compares two rankings and returns how similar they are (rho) plus the p-value
def rho_between(r1: pd.Series, r2: pd.Series):
    k = len(r1)
    rho, _ = spearmanr(r1.values, r2.values)
    return float(rho), exact_perm_pvalue(rho, k)


# reads the input CSV and checks it has all the columns we need before doing anything else
def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    need = {"dataset", "method", "seed", "sample_size", "parameter", "value"}
    missing = need - set(df.columns)
    if missing:
        sys.exit(f"Input file is missing columns: {missing}")
    # normalize parameter codes (e.g. "rc" -> "RC") so matching works later
    df["parameter"] = df["parameter"].str.upper().str.strip()
    return df


def main(path: str = "sa_indices.csv", outdir: str = "stability_out"):
    df = load_data(path)
    out = Path(outdir)
    out.mkdir(exist_ok=True)

    seed_rows, conv_rows, ref_rows, agree_rows = [], [], [], []

    for (ds, method), g in df.groupby(["dataset", "method"]):
        # Parameter set is inferred from the data itself for this
        # (dataset, method) group -- this is what lets 2017 Sobol carry 6
        # groups (incl. Gateways) while everything else carries 5.
        params = sorted(g["parameter"].unique())
        sizes = sorted(g["sample_size"].unique())
        seeds = sorted(g["seed"].unique())

        # -- 1. seed stability: pairwise rho across seeds at each size
        for n in sizes:
            rankings = {
                s: ranking_from_values(g[(g.sample_size == n) & (g.seed == s)], params)
                for s in seeds
            }
            pair_rhos = []
            for s1, s2 in itertools.combinations(seeds, 2):
                rho, p = rho_between(rankings[s1], rankings[s2])
                pair_rhos.append(rho)
                seed_rows.append(dict(dataset=ds, method=method, sample_size=n,
                                      seed_a=s1, seed_b=s2, n_params=len(params),
                                      rho=rho, p_exact=p))
            seed_rows.append(dict(dataset=ds, method=method, sample_size=n,
                                  seed_a="MEAN", seed_b="", n_params=len(params),
                                  rho=float(np.mean(pair_rhos)), p_exact=np.nan))

        # -- 2. convergence: rho between consecutive sizes, per seed
        for s in seeds:
            # zip(sizes, sizes[1:]) pairs up each size with the next one,
            # e.g. sizes=[8,16,32] -> pairs (8,16) and (16,32)
            for n1, n2 in zip(sizes, sizes[1:]):
                r1 = ranking_from_values(g[(g.sample_size == n1) & (g.seed == s)], params)
                r2 = ranking_from_values(g[(g.sample_size == n2) & (g.seed == s)], params)
                rho, p = rho_between(r1, r2)
                conv_rows.append(dict(dataset=ds, method=method, seed=s,
                                      size_from=n1, size_to=n2, n_params=len(params),
                                      rho=rho, p_exact=p))

        # -- 4. reference ranking: seed-averaged values at largest size
        # (uses ALL parameters present for this dataset/method -- e.g. GW
        # is included for 2017 Sobol here)
        nmax = sizes[-1]
        avg = (g[g.sample_size == nmax]
               .groupby("parameter")["value"].mean().reindex(params))
        rank = avg.rank(ascending=False).astype(int)
        for p_ in params:
            ref_rows.append(dict(dataset=ds, method=method, sample_size=nmax,
                                 parameter=p_, mean_value=avg[p_],
                                 reference_rank=rank[p_]))

    # -- 3. Morris vs Sobol agreement at largest size (from reference rankings)
    # Restricted to the INTERSECTION of parameters available for both methods
    # in that dataset (this is what handles 2017's Gateways-only-in-Sobol
    # asymmetry: GW is simply excluded from this one comparison).
    ref = pd.DataFrame(ref_rows)
    for ds, g in ref.groupby("dataset"):
        piv = g.pivot(index="parameter", columns="method", values="reference_rank")
        if {"morris", "sobol"} <= set(piv.columns):
            common = piv.dropna(subset=["morris", "sobol"])
            excluded = set(piv.index) - set(common.index)
            rho, p = rho_between(common["morris"], common["sobol"])
            agree_rows.append(dict(
                dataset=ds, rho_morris_vs_sobol=rho, p_exact=p,
                n_params_compared=len(common),
                params_excluded_from_comparison=",".join(sorted(excluded)) or "none",
            ))

    pd.DataFrame(seed_rows).to_csv(out / "seed_stability.csv", index=False)
    pd.DataFrame(conv_rows).to_csv(out / "convergence.csv", index=False)
    ref.to_csv(out / "reference_rankings.csv", index=False)
    pd.DataFrame(agree_rows).to_csv(out / "method_agreement.csv", index=False)

    print("=== Reference rankings (seed-averaged @ largest size) ===")
    print(ref.pivot_table(index=["dataset", "parameter"], columns="method",
                          values="reference_rank"))
    print("\n=== Mean seed-stability rho per size ===")
    ss = pd.DataFrame(seed_rows)
    print(ss[ss.seed_a == "MEAN"].pivot_table(
        index=["dataset", "method"], columns="sample_size", values="rho"))
    print("\n=== Method agreement (Sobol vs Morris) ===")
    print(pd.DataFrame(agree_rows).to_string(index=False))
    print(f"\nAll outputs written to {out}/")


if __name__ == "__main__":
    main(*sys.argv[1:])

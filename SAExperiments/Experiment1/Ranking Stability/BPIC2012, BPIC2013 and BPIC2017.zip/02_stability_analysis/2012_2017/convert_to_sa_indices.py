"""
Converts Ugur's raw summary CSVs into the sa_indices.csv format expected by
spearman_stability_v2.py.

EDIT THE FILE PATHS BELOW to match your actual filenames, then run:
    python3 convert_to_sa_indices.py
"""
import pandas as pd

NAME_TO_CODE = {
    "Arrival Calendar": "AC",
    "Arrival Distribution": "AD",
    "Resource Calendars": "RC",
    "Resource Numbers": "RN",
    "Tasks and Resources Distributions": "TR",
    "Gateways": "GW",
}

# --- EDIT THESE FOUR LINES to match your actual filenames ---
SOBOL_2012_FILE = "sobol_final_summary_cycle.csv"
SOBOL_2017_FILE = "sobol_final_summary.csv"
MORRIS_2012_FILE = "morris_2012.csv"
MORRIS_2017_FILE = "morris_2017.csv"
# --------------------------------------------------------------

# loads one raw CSV file and reshapes it into the common column format
# (same column names for every dataset/method, so they can all be stacked together)
def load_one(path, method, value_col):
    df = pd.read_csv(path)
    df = df.rename(columns={
        "n_samples": "sample_size",
        "group": "parameter",
        "name": "parameter",   # Morris files use "name" instead of "group"
        value_col: "value",
    })
    # turn the long parameter names (e.g. "Arrival Calendar") into short codes (e.g. "AC")
    df["parameter"] = df["parameter"].map(NAME_TO_CODE)
    if df["parameter"].isna().any():
        bad = df[df["parameter"].isna()]
        raise ValueError(f"Unrecognised group name(s) in {path}:\n{bad}")
    df["method"] = method
    return df[["dataset", "method", "seed", "sample_size", "parameter", "value"]]

# load all four raw files (2 datasets x 2 methods) into one common format
parts = [
    load_one(SOBOL_2012_FILE, "sobol", "ST"),
    load_one(SOBOL_2017_FILE, "sobol", "ST"),
    load_one(MORRIS_2012_FILE, "morris", "mu_star"),
    load_one(MORRIS_2017_FILE, "morris", "mu_star"),
]

# stack all four into one long table and save it
out = pd.concat(parts, ignore_index=True)
out.to_csv("sa_indices.csv", index=False)

print(out.groupby(["dataset", "method"])["parameter"].apply(lambda s: sorted(s.unique())))
print("\nTotal rows:", len(out))
print("Saved to sa_indices.csv")

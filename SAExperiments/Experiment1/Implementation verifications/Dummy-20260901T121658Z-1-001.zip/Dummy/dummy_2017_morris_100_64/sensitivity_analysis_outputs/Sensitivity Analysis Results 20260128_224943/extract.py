import json
import csv
from pathlib import Path

# Path to the JSON file
json_path = Path("morris_first_order.json")
csv_path = json_path.with_suffix(".csv")

# Load JSON data
with open(json_path, "r", encoding="utf-8") as f:
    data = json.load(f)

# Write group and ST to CSV
with open(csv_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["name", "mu_star"])  # header

    for entry in data:
        writer.writerow([entry.get("name"), entry.get("mu_star")])

print(f"CSV written to: {csv_path}")

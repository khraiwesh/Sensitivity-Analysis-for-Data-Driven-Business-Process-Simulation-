import json
import csv
from pathlib import Path

# Path to the JSON file
json_path = Path("sobol_first_and_total_order.json")
csv_path = json_path.with_suffix(".csv")

# Load JSON data
with open(json_path, "r", encoding="utf-8") as f:
    data = json.load(f)

# Write group and ST to CSV
with open(csv_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["group", "ST"])  # header

    for entry in data:
        writer.writerow([entry.get("group"), entry.get("ST")])

print(f"CSV written to: {csv_path}")
